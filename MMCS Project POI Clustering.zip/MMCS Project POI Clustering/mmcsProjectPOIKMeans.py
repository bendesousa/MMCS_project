import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import numpy as np
"""
we are going to implement k-means clustering to take whatever fuckload of geographic points you want and put them into k groups
according to how close together they are.

i have arbitrarily decided that k = 50. that just kinda seems like a nice number of candidates to consider. that can change quite easily

i had a vba script that did this, but apparently the uni won't let me use my account to edit in excel on a mac, so here we are with python.
honestly though, kinda great because i can actually just use pre-existing libraries to do it instead of writing four different functions and
doing it all by hand.
"""
# create a data frame with the data from edinburgh pois
pois = pd.read_csv("edinburgh_pois.csv")
print(pois.head())

# define an nx2 vector with the latitude and longitude of each poi
X = pois[['lat', 'lon']].values
# arbitrarily we are considering 50 potential stations sited at the geographic mean of the pois they serve
k = 50
# thank you sci-kit for writing the hard part for me
kmeans = KMeans(n_clusters=k, random_state=42)
# add each poi's assigned cluster to the data frame
pois['cluster'] = kmeans.fit_predict(X)
"""
plt.scatter(pois['lon'], pois['lat'], c=pois['cluster'], cmap='tab10')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('K-Means Clustering of Points of Interest')
plt.show()
"""
# find the geographic mean of each cluster and create a new data frame with it
cluster_centers = (
    pois.groupby('cluster')[['lat', 'lon']]
    .mean()
    .reset_index()
)

# if you want cool matplots of each POI and its cluster and its cluster's geographic mean put this back in

plt.scatter(pois['lon'], pois['lat'], c=pois['cluster'], cmap='tab10', alpha=0.5)
plt.scatter(cluster_centers['lon'], cluster_centers['lat'], c='black', marker='x', s=25, label='Cluster Centers')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.legend()
plt.title('K-Means Clustering of Points of Interest')
# plt.show()
plt.savefig('50 Means Clustering of edinburgh_pois.png', transparent = True)

# write our two dataframes to csv files. the first has each poi and its assigned cluster. the second has each cluster and its geographical mean
pois.to_csv("enbraPOIClusterAssingments.csv", index = False)
cluster_centers.to_csv("enbraPOIClusterLocations.csv", index=False)